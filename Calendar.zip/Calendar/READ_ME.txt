This is my work sample for the XLP Summer internship 2016.
It is a calendar application programmed by me in java.
I have given credit to the creator of the background images 
and the external class that I used to customized text prompts.